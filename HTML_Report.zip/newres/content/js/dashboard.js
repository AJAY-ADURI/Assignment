/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7879464285714286, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.8303571428571429, 500, 1500, "/biography/Sachin-Tendulkar-94"], "isController": false}, {"data": [0.9444444444444444, 500, 1500, "/biography/Sachin-Tendulkar/additional-info-146"], "isController": false}, {"data": [0.9044444444444445, 500, 1500, "/-48"], "isController": false}, {"data": [0.5955056179775281, 500, 1500, "04_Click_on_Quick_Facts_Link"], "isController": true}, {"data": [0.5955056179775281, 500, 1500, "/facts/Sachin-Tendulkar-161"], "isController": false}, {"data": [0.9444444444444444, 500, 1500, "03_click_on_References_Link"], "isController": true}, {"data": [0.9044444444444445, 500, 1500, "01_Launch_URL"], "isController": true}, {"data": [0.8866666666666667, 500, 1500, "/search-84"], "isController": false}, {"data": [0.8654708520179372, 500, 1500, "/topic-content/topic/648271-114"], "isController": false}, {"data": [1.0, 500, 1500, "/cdn-cgi/rum?-141"], "isController": false}, {"data": [0.3688888888888889, 500, 1500, "01_Search"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1345, 0, 0.0, 444.71895910780694, 22, 7991, 219.0, 959.6000000000004, 1605.8000000000034, 3598.7999999999993, 4.485247038736527, 67.38073153399617, 16.42550756551962], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["/biography/Sachin-Tendulkar-94", 224, 0, 0.0, 555.9107142857143, 155, 6469, 255.5, 1183.0, 2374.0, 3737.5, 0.7510830349119489, 16.377307683763867, 0.7367081459817058], "isController": false}, {"data": ["/biography/Sachin-Tendulkar/additional-info-146", 45, 0, 0.0, 267.8444444444445, 129, 1960, 170.0, 491.19999999999993, 1040.6999999999982, 1960.0, 0.15502380476646527, 2.7879187688181672, 0.1657456117497709], "isController": false}, {"data": ["/-48", 225, 0, 0.0, 406.9155555555556, 148, 4545, 212.0, 941.2000000000002, 1390.8999999999996, 3496.980000000004, 0.7509762691498949, 18.310519169712293, 0.7312892176496111], "isController": false}, {"data": ["04_Click_on_Quick_Facts_Link", 178, 0, 0.0, 896.9325842696628, 429, 7991, 538.5, 1706.6999999999998, 2752.6499999999983, 5301.0500000000275, 0.6026543878656555, 11.76066786083085, 0.6419701540069745], "isController": true}, {"data": ["/facts/Sachin-Tendulkar-161", 178, 0, 0.0, 896.9325842696628, 429, 7991, 538.5, 1706.6999999999998, 2752.6499999999983, 5301.0500000000275, 0.6026543878656555, 11.76066786083085, 0.6419701540069745], "isController": false}, {"data": ["03_click_on_References_Link", 45, 0, 0.0, 267.8444444444445, 129, 1960, 170.0, 491.19999999999993, 1040.6999999999982, 1960.0, 0.15502380476646527, 2.7879187688181672, 0.1657456117497709], "isController": true}, {"data": ["01_Launch_URL", 225, 0, 0.0, 406.9155555555556, 148, 4545, 212.0, 941.2000000000002, 1390.8999999999996, 3496.980000000004, 0.7505228642621027, 18.299464121462954, 0.7308476988968982], "isController": true}, {"data": ["/search-84", 225, 0, 0.0, 407.0533333333331, 148, 3752, 209.0, 842.8, 1232.0999999999995, 3432.480000000001, 0.7541351745403966, 9.212212852558194, 0.7423452661259238], "isController": false}, {"data": ["/topic-content/topic/648271-114", 223, 0, 0.0, 496.13901345291464, 146, 7444, 228.0, 1008.9999999999998, 1825.9999999999986, 5240.039999999989, 0.7516364102114693, 9.015377631991399, 0.6898371984606622], "isController": false}, {"data": ["/cdn-cgi/rum?-141", 223, 0, 0.0, 30.730941704035885, 22, 261, 28.0, 36.0, 41.0, 131.47999999999934, 0.7546122714167761, 0.2800318975960692, 12.926277680396323], "isController": false}, {"data": ["01_Search", 225, 0, 0.0, 1482.6888888888886, 174, 8106, 877.0, 3494.8, 5142.599999999998, 7843.880000000008, 0.7539128074707733, 34.81503246641738, 14.963601848803625], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1345, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
